# Student_Marks_Prediction
This is a ML model . It predicts the marks of student that how much marks student can get if he study for 3 hours or 4 hours etc.
